import { inject } from '@angular/core';
import { CanActivateFn, Router, Routes } from '@angular/router';

import { HomeComponent } from './components/home/home.component';
import { AuthComponent } from './components/auth/auth.component';
import { CreatePinComponent } from './components/create-pin/create-pin.component';
import { PinDetailComponent } from './components/pin-detail/pin-detail.component';
import { AuthService } from './services/auth.service';

const authGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);
  
  if (authService.currentUser()) {
    return true;
  } else {
    router.navigate(['/auth']);
    return false;
  }
};

export const APP_ROUTES: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'auth', component: AuthComponent },
  { path: 'create', component: CreatePinComponent, canActivate: [authGuard] },
  { path: 'pin/:id', component: PinDetailComponent },
  { path: '**', redirectTo: '/home' }
];