
import { User } from './user.model';
import { Comment } from './comment.model';

export interface Pin {
  id: string;
  title: string;
  imageUrl: string;
  author: User;
  isAd: boolean;
  likes: number;
  comments: Comment[];
}