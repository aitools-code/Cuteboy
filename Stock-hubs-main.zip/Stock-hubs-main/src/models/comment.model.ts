import { User } from './user.model';

export interface Comment {
  author: User;
  text: string;
  timestamp: Date;
}
