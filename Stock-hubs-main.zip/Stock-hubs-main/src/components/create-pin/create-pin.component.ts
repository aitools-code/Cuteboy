
import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { PinService } from '../../services/pin.service';

@Component({
  selector: 'app-create-pin',
  templateUrl: './create-pin.component.html',
  imports: [ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreatePinComponent {
  createPinForm: FormGroup;
  imagePreview = signal<string | ArrayBuffer | null>(null);

  constructor(
    private fb: FormBuilder,
    private pinService: PinService,
    private router: Router
  ) {
    this.createPinForm = this.fb.group({
      title: ['', Validators.required],
      image: [null, Validators.required],
      isAd: [false],
    });
  }

  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = () => this.imagePreview.set(reader.result);
      reader.readAsDataURL(file);
    }
  }

  onSubmit(): void {
    if (this.createPinForm.valid && this.imagePreview()) {
      const { title, isAd } = this.createPinForm.value;
      this.pinService.addPin(title, this.imagePreview() as string, isAd);
      this.router.navigate(['/home']);
    }
  }
}
