
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { PinService } from '../../services/pin.service';
import { PinCardComponent } from '../pin-card/pin-card.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  imports: [PinCardComponent, RouterModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HomeComponent {
  pinService = inject(PinService);
  pins = this.pinService.pins;
}
