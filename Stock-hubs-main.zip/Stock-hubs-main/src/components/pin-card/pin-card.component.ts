import { Component, ChangeDetectionStrategy, input, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Pin } from '../../models/pin.model';
import { AuthService } from '../../services/auth.service';
import { NgOptimizedImage } from '@angular/common';

@Component({
  selector: 'app-pin-card',
  templateUrl: './pin-card.component.html',
  imports: [NgOptimizedImage],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PinCardComponent {
  pin = input.required<Pin>();
  
  private authService = inject(AuthService);
  private router = inject(Router);

  downloadPin(event: MouseEvent): void {
    event.stopPropagation(); // Prevent triggering other click events on the card
    if (this.authService.currentUser()) {
      // This method uses the Fetch API to get the image as a blob
      // and creates a temporary link to trigger the browser's download functionality.
      fetch(this.pin().imageUrl)
        .then(response => {
          if (!response.ok) {
            throw new Error('Network response was not ok.');
          }
          return response.blob();
        })
        .then(blob => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.style.display = 'none';
          a.href = url;
          a.download = `${this.pin().title.replace(/ /g, '_') || 'pin'}.jpg`;
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
          a.remove();
        })
        .catch(() => {
          // Fallback for when fetch fails (e.g., CORS issues) by opening in a new tab.
          window.open(this.pin().imageUrl, '_blank');
        });
    } else {
      this.router.navigate(['/auth']);
    }
  }

  viewPin(): void {
    this.router.navigate(['/pin', this.pin().id]);
  }
}