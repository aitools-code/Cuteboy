import { Component, ChangeDetectionStrategy, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { NgOptimizedImage, DatePipe } from '@angular/common';

import { Pin } from '../../models/pin.model';
import { PinService } from '../../services/pin.service';
import { AuthService } from '../../services/auth.service';
import { PinCardComponent } from '../pin-card/pin-card.component';

@Component({
  selector: 'app-pin-detail',
  templateUrl: './pin-detail.component.html',
  imports: [
    NgOptimizedImage,
    DatePipe,
    ReactiveFormsModule,
    PinCardComponent,
    RouterModule
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PinDetailComponent {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private pinService = inject(PinService);
  private authService = inject(AuthService);
  private fb = inject(FormBuilder);

  private readonly pinId: string | null = this.route.snapshot.paramMap.get('id');

  pin = computed(() => {
    if (!this.pinId) return undefined;
    return this.pinService.pins().find(p => p.id === this.pinId);
  });
  
  morePins = computed(() => {
    return this.pinService.popularPins().filter(p => p.id !== this.pinId);
  });

  currentUser = this.authService.currentUser;
  commentForm: FormGroup;

  constructor() {
    if (!this.pinId || !this.pinService.getPinById(this.pinId)) {
      this.router.navigate(['/home']);
    }

    this.commentForm = this.fb.group({
      text: ['', Validators.required],
    });
  }

  likePin(): void {
    if (this.pin()) {
      this.pinService.toggleLike(this.pin()!.id);
    }
  }

  submitComment(): void {
    if (this.commentForm.invalid || !this.pin()) {
      return;
    }
    this.pinService.addComment(this.pin()!.id, this.commentForm.value.text);
    this.commentForm.reset();
  }
  
  sharePin(): void {
    if (navigator.share) {
      navigator.share({
        title: this.pin()?.title,
        text: `Check out this pin on PinVista: ${this.pin()?.title}`,
        url: window.location.href,
      }).catch(console.error);
    } else {
      // Fallback for browsers that don't support the Web Share API
      navigator.clipboard.writeText(window.location.href).then(() => {
        alert('Link copied to clipboard!');
      });
    }
  }
}