
import { Injectable, signal, WritableSignal, computed, inject } from '@angular/core';
import { Pin } from '../models/pin.model';
import { AuthService } from './auth.service';
import { Comment } from '../models/comment.model';

@Injectable({ providedIn: 'root' })
export class PinService {
  private _pins: WritableSignal<Pin[]> = signal([]);
  public pins = computed(() => this._pins());
  public popularPins = computed(() => 
    this._pins()
      .slice()
      .sort((a, b) => (b.likes + b.comments.length) - (a.likes + a.comments.length))
  );

  private authService = inject(AuthService);

  constructor() {
    // Pre-populated data removed. The feed will start empty.
  }

  addPin(title: string, imageUrl: string, isAd: boolean) {
    const currentUser = this.authService.currentUser();
    if (!currentUser) return;

    const newPin: Pin = {
      id: `p${Date.now()}`,
      title,
      imageUrl,
      author: currentUser,
      isAd,
      likes: 0,
      comments: [],
    };

    this._pins.update(pins => [newPin, ...pins]);
  }

  getPinById(id: string): Pin | undefined {
    return this._pins().find(p => p.id === id);
  }

  toggleLike(pinId: string): void {
    this._pins.update(pins =>
      pins.map(pin =>
        pin.id === pinId ? { ...pin, likes: pin.likes + 1 } : pin
      )
    );
  }

  addComment(pinId: string, text: string): void {
    const currentUser = this.authService.currentUser();
    if (!currentUser) return;

    this._pins.update(pins =>
      pins.map(pin => {
        if (pin.id === pinId) {
          const newComment: Comment = {
            author: currentUser,
            text,
            timestamp: new Date(),
          };
          // Add new comment to the beginning of the array
          return { ...pin, comments: [newComment, ...pin.comments] };
        }
        return pin;
      })
    );
  }
}