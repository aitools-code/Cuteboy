
import { Injectable, signal, WritableSignal } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private users: User[] = [
    { id: '1', email: 'demo@pinvista.com', name: 'Demo User' }
  ];
  private passwords = new Map<string, string>([['1', 'password123']]);
  
  currentUser: WritableSignal<User | null> = signal(null);

  constructor(private router: Router) {}

  login(email: string, pass: string): boolean {
    const user = this.users.find(u => u.email === email);
    if (user && this.passwords.get(user.id) === pass) {
      this.currentUser.set(user);
      this.router.navigate(['/home']);
      return true;
    }
    return false;
  }

  register(name: string, email: string, pass: string): boolean {
    if (this.users.some(u => u.email === email)) {
      return false; // User already exists
    }
    const newUser: User = {
      id: (this.users.length + 1).toString(),
      name,
      email,
    };
    this.users.push(newUser);
    this.passwords.set(newUser.id, pass);
    this.currentUser.set(newUser);
    this.router.navigate(['/home']);
    return true;
  }

  logout(): void {
    this.currentUser.set(null);
    this.router.navigate(['/auth']);
  }
}
